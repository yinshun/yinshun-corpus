const REGEXP_IMAGE = new RegExp('^(\\d+[abcde]?)\\-(\\d+)([abcd])$');

export default REGEXP_IMAGE;
