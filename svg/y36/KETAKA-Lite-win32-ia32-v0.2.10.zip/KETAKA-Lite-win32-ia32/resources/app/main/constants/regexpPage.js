const REGEXP_PAGE = new RegExp('^(\\d+)\\-(\\d+)\\-(\\d+)([abcd])?$');

export default REGEXP_PAGE;
